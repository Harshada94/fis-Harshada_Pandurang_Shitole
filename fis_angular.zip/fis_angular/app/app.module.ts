import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { LoginComponent } from './adminLogin/login.component';
import { DisplayComponent } from './display/display.component';
import { RegisterComponent } from './register/register.component';
import { MydemoComponent } from './mydemo/mydemo.component';
import { BackendComponent } from './backend/backend.component';
import { PassengerComponent } from './passenger/passenger.component';
import { RouterModule } from '@angular/router';
import { PassengersComponent } from './passengers/passengers.component';
import { CreateComponent } from './create/create.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DisplayComponent,
    RegisterComponent,
    MydemoComponent,
    PassengerComponent,
    BackendComponent,
    PassengersComponent,
    CreateComponent,
    PassengersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
   FormsModule,
    HttpClientModule,
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
