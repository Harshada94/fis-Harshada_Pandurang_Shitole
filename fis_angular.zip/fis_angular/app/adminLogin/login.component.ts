import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  name = 'Harshada';
  city = 'Pune';
  Password = '12345';

  


  showData():void{

    //window.close();
    this.router.navigateByUrl('/backend');

    console.log(this.name+" "+this.Password+" "+this.city);
  }

  
  constructor(private router:Router) { }

  ngOnInit(): void {
  }

}
