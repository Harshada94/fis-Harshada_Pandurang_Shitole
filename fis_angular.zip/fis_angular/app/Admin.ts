export class Admin{
    flight_id : any;
    airline_name  :any;
    from_location :any;
    to_location :any;
    departure_time :any;
    arrival_time :any;
    duration :any;
    total_seats :any;
}