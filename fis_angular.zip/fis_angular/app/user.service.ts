import { Injectable } from '@angular/core';
import { Admin } from 'src/app/Admin';
 
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }

  getUsers():any{
    return this.http.get("http://localhost:8083/flights/listAll");
  }

  createUser(user:Admin):void{
    
  }

  ValidateUser(user:Admin): boolean {


    return false;
  }
}