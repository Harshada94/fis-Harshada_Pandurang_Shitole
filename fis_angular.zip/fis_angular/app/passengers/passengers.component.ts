import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-passengers',
  templateUrl: './passengers.component.html',
  styleUrls: ['./passengers.component.css']
})
export class PassengersComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }


  name = 'Harshada';
  city = 'Pune';
  Password = '12345';

  show1(){

    this.router.navigateByUrl('login');

    console.log(this.name+" "+this.Password+" "+this.city);
  }


  show2(){

    //window.close();
    this.router.navigateByUrl('create');

    console.log(this.name+" "+this.Password+" "+this.city);
  }
}
