import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mydemo',
  templateUrl: './mydemo.component.html',
  styleUrls: ['./mydemo.component.css']
})
export class MydemoComponent implements OnInit {
  title : any;
  director : any;
  cast : any;
  releaseDate : any;
  movies=[{
    title : 'Ninja',
    director: 'Japan',
    cast: 'JPN',
    releaseDate: '20-6-2021'
  },{
    title : 'Avengers',
    director: 'American',
    cast: 'US',
    releaseDate: '9-5-2021'
  }];

  constructor() { }

  ngOnInit(): void {
  }

}
