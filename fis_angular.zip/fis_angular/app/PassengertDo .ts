export class PassengertDo {
	
    pid : any;
    password:any;
    fname: any;
    lname:any;
    address:any;
    mobile_number:any;
    email:any;
        
       
}