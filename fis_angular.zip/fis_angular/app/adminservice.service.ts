import { Injectable } from '@angular/core';
import { Admin } from 'src/app/Admin';
import { PassengertDo } from './PassengertDo ';

import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class AdminserviceService {

  constructor(private http:HttpClient) { }

  getUsers():any{
    return this.http.get("http://localhost:8083/flights/all");
  }

  getAllPassengers():any{
    return this.http.get("http://localhost:8083/flights/listAll");
  }
  
}
