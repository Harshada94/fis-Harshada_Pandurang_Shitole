import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './adminLogin/login.component';
import { AppComponent } from './app.component';
import { BackendComponent } from './backend/backend.component';
import { CreateComponent } from './create/create.component';
import { DisplayComponent } from './display/display.component';
import { InsertComponent } from './insert/insert.component';
import { MydemoComponent } from './mydemo/mydemo.component';
import { PassengerComponent } from './passenger/passenger.component';
import { PassengersComponent } from './passengers/passengers.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  {path:'login' , component: LoginComponent },
  {path:'register' , component: RegisterComponent },
  {path:'display' , component: DisplayComponent },
  {path:'mydemo' , component: MydemoComponent},
  {path:'backend' , component: BackendComponent},
  {path:'passenger',component: PassengerComponent},
  {path:'appIn',component:AppComponent},
  {path:'login', component: LoginComponent},
  {path:'passengers',component: PassengersComponent},
  {path:'create', component:CreateComponent}
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
