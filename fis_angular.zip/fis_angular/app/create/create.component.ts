import { Component, OnInit } from '@angular/core';
import { PostService } from '../post.service';
import { PassengertDo } from '../PassengertDo ';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  constructor(private service:PostService) { }
  tid:any;
 tpassword:any;
      tfname:any;
      tlname:any;
      taddress:any;
      tmobile_number:any;
      temail:any;
  
  ngOnInit(): void {
  }

  insertData(){

  
   let post : PassengertDo = {
    
      "pid":this.tid,
      "password":this.tpassword,
      "fname":this.tfname,
      "lname":this.tlname,
      "address":this.taddress,
      "mobile_number":this.tmobile_number,
      "email":this.temail,

    }
   this.service.insertPostData(post);
  }
}
