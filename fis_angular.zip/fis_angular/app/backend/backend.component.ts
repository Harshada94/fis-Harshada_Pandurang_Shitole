import { Component, OnInit } from '@angular/core';
import { AdminserviceService } from '../adminservice.service';


@Component({
  selector: 'app-display',
  templateUrl: './backend.component.html',
  styleUrls: ['./backend.component.css']
})
export class BackendComponent implements OnInit {

  fullName="Angular Programming";
  admin:any;
  passenger:any;

  constructor(private services:AdminserviceService) { }

  ngOnInit(): void {
  }


  public display():void{
   
    this.services.getUsers()
    .subscribe( (response: any) =>{
      this.admin=response;
      console.log(response);
    }

    
    );
      
  }

  public passengers():void{
    
    this.services.getAllPassengers()
  .subscribe( (response: any) =>{
    this.passenger=response;
    console.log(response);
  

  });

}
}