package com.example.Passengerservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Passengerservice.Service.PassengerService;
import com.example.Passengerservice.model.Passenger;

@RestController
@RequestMapping("/passengers")

public class PassengerController {
	
	
		@Autowired
		PassengerService service;
		
		
		@PostMapping("/add")
		public Passenger addPassenger(@RequestBody Passenger passenger) {
			return service.addPassenger(passenger);
		}
		
		@GetMapping("/listAll")
		public List<Passenger> getAll()
		{
			return service.findAllPassengers();
		}
		
		
		@DeleteMapping("/delete/{pid}")
		public String deletePassenger(@PathVariable("pid")int pid) {
			
		return service.deletePassengerById(pid);
		}
		
		@GetMapping("/pid/{pid}")
		public List<Passenger> getDetailsById(@PathVariable("pid")int pid)
		{
			return service.findDetailsById(pid);
		}
		
		

}
