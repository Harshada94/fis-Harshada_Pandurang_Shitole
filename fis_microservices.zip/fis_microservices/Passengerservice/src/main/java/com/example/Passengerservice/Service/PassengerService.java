package com.example.Passengerservice.Service;

import java.util.List;

import com.example.Passengerservice.model.Passenger;

public interface PassengerService{
	
	//Register
	public Passenger addPassenger(Passenger passenger);
	
	
	//Login
	public List<Passenger> findDetailsById(int id);

	//Admin can Perform on passengers
	public String deletePassengerById(int pid);
	public List<Passenger> findAllPassengers();

	
	

}
