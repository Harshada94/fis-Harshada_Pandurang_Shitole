package com.example.Passengerservice.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.Passengerservice.model.Passenger;

public interface PassengerRepo extends JpaRepository<Passenger,Integer>{
	
	@Query("select a from Passenger a where a.pid=?1")
	public List<Passenger> passengersById(int pid);

}
