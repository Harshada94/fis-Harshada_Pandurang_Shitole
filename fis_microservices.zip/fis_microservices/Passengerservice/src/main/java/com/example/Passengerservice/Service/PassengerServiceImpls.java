package com.example.Passengerservice.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Passengerservice.model.Passenger;
import com.example.Passengerservice.repo.PassengerRepo;

@Service
public class PassengerServiceImpls implements PassengerService {
	
	@Autowired
	PassengerRepo repo;

	@Override
	public Passenger addPassenger(Passenger passenger) {
		// TODO Auto-generated method stub
		return repo.save(passenger);
	}

	@Override
	public List<Passenger> findDetailsById(int pid) {
		// TODO Auto-generated method stub
		return repo.passengersById(pid);
	}

	@Override
	public String deletePassengerById(int pid) {
		// TODO Auto-generated method stub
		repo.deleteById(pid);
		return "Passenger Deleted.......!";
	}

	@Override
	public List<Passenger> findAllPassengers() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}
	
	

}
