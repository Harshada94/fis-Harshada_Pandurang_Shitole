package com.example.Adminservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.Adminservice.model.Admin;
import com.example.Adminservice.model.PassengertDo;
import com.example.Adminservice.repo.adminRepo;
import com.example.Adminservice.service.FeignProxy;


@Service
@Component
public class AdminServiceImpl implements AdminService{
	
	@Autowired
	FeignProxy proxy;
	
	@Autowired
	adminRepo repo;
	
	@Autowired
	RestTemplate template;

	@Override
	public List<Admin> findAllFlights() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Admin addFlight(Admin admin) {
		// TODO Auto-generated method stub
		return repo.save(admin);
	}

	@Override
	public String deleteFlightById(int Flight_id) {
		// TODO Auto-generated method stub
		repo.deleteById(Flight_id);
		return "Flight Deleted.....";
	}

	@Override
	public List<Admin> findAllFlightsById(int Flight_id) {
		// TODO Auto-generated method stub
		return repo.findFlightsById(Flight_id);
	}

	@Override
	public List<Admin> findAllFlightsByLocation(String from_location, String to_location) {
		// TODO Auto-generated method stub
		return repo.findFlightsByLocation(from_location, to_location);
	}

	@Override
	public String deletePassengerById(int pid) {
		// TODO Auto-generated method stub
		proxy.deletePassenger(pid);
		return "Passenger Deleted......";
	}

	@Override
	public List<PassengertDo> findAllPassengers() {
		// TODO Auto-generated method stub
		return proxy.getList();
	}

	@Override
	public PassengertDo addPassenger(PassengertDo passenger) {
		// TODO Auto-generated method stub
		return proxy.addPassenger(passenger);
	}

	

}
