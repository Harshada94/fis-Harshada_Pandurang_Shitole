package com.example.Adminservice.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.Adminservice.model.Admin;

public interface adminRepo extends JpaRepository<Admin,Integer> {
	
	@Query("select a from Admin a where a.flight_id=?1")
	public List<Admin> findFlightsById(int Flight_id);
	
	@Query("select a from Admin a where a.from_location=?1 and a.to_location=?1")
	public List<Admin> findFlightsByLocation(String from_location,String to_location);

}
