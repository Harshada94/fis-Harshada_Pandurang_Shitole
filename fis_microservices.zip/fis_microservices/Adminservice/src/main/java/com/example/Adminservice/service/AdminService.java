package com.example.Adminservice.service;

import java.util.List;

import com.example.Adminservice.model.Admin;
import com.example.Adminservice.model.PassengertDo;

public interface AdminService {

	
	public List<Admin> findAllFlights();
	public Admin addFlight(Admin admin);
	public String deleteFlightById(int Flight_id);
	public List<Admin> findAllFlightsById(int Flight_id);
	public List<Admin> findAllFlightsByLocation(String from_location,String to_location);

	
	//Admin can perform on passengers
	public String deletePassengerById(int pid);
	public List<PassengertDo> findAllPassengers();
	public PassengertDo addPassenger(PassengertDo passenger);
}
