package com.example.Adminservice.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.Adminservice.model.PassengertDo;

@FeignClient(name="Passengerservice")
public interface FeignProxy {
	
	
	@GetMapping("/passengers/listAll")
	public List<PassengertDo> getList();
	
	
	
	@DeleteMapping("/passengers/delete/{pid}")
	public String deletePassenger(@PathVariable("pid")int pid);
	
	
	@PostMapping("passengers/add")
	public PassengertDo addPassenger(@RequestBody PassengertDo passenger);
	

}
