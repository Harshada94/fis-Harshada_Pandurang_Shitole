package com.example.Adminservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Adminservice.model.Admin;
import com.example.Adminservice.model.PassengertDo;
import com.example.Adminservice.service.AdminService;

@RestController
@RequestMapping("/flights")
@CrossOrigin("*")
public class AdminController {
	
	@Autowired
	AdminService service;
	
	@GetMapping("/all")
	public List<Admin> getAll()
	{
		return service.findAllFlights();
	}
	
	@PostMapping("/addAll")
	public Admin addFlight(@RequestBody Admin admin) {
		return service.addFlight(admin);
	}
	
	@DeleteMapping("/delete/{flight_id}")
	public String deleteFlight(@PathVariable("flight_id")int flight_id) {
		
	return service.deleteFlightById(flight_id);
	}
	
	@GetMapping("/flightId/{flight_id}")
	public List<Admin> getAllById(@PathVariable("flight_id")int flight_id)
	{
		return service.findAllFlightsById(flight_id);
	}
	
	@GetMapping("/Locations/{from_location}/{to_location}")
	public List<Admin> getAllById(@PathVariable("from_location")String from_location,@PathVariable("to_location")String to_location)
	{
		return service.findAllFlightsByLocation(from_location, to_location);
	}

	@GetMapping("/listAll")
	public List<PassengertDo> getList()
	{
		return service.findAllPassengers();
	}
	
	
	@DeleteMapping("/delete/{pid}")///http://localhost:8083/flights/delete/{pid}
	public String deletePassenger(@PathVariable("pid")int pid) {
		
	return service.deletePassengerById(pid);
	}
	
	@PostMapping("/add")
	public PassengertDo addPassenger(@RequestBody PassengertDo passenger) {
		return service.addPassenger(passenger);
	}
	
	
	
}
