package com.example.Adminservice.model;


public class PassengertDo {
	
int pid;
	
	
	String password;
	
	String fname;
	
	String lname;
	
	String address;
	
	Long mobile_number;
	
	String email;
	

	
	public PassengertDo() {
		
	}

	
	public int getPid() {
		return pid;
	}



	public void setPid(int pid) {
		this.pid = pid;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getFname() {
		return fname;
	}



	public void setFname(String fname) {
		this.fname = fname;
	}



	public String getLname() {
		return lname;
	}



	public void setLname(String lname) {
		this.lname = lname;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public Long getMobile_number() {
		return mobile_number;
	}



	public void setMobile_number(Long mobile_number) {
		this.mobile_number = mobile_number;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}
	

	public PassengertDo(int pid, String password, String fname, String lname, String address, Long mobile_number,
			String email) {
		super();
		this.pid = pid;
		this.password = password;
		this.fname = fname;
		this.lname = lname;
		this.address = address;
		this.mobile_number = mobile_number;
		this.email = email;
	}


}
